package view;

import model.AntrianPasien;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.io.*;

public class FormAntrian extends JFrame {
    private JTextField tfIdPasien, tfWaktu;
    private JButton btnTambah;
    private JTextArea taAntrian;

    public FormAntrian() {
        setTitle("Sistem Antrian Pasien");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 450);
        setLocationRelativeTo(null);

        // Panel utama
        JPanel panel = new JPanel();
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));
        panel.setLayout(new BorderLayout(10, 10));
        add(panel);

        // Judul
        JLabel lblTitle = new JLabel("Sistem Antrian Pasien", SwingConstants.CENTER);
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 22));
        panel.add(lblTitle, BorderLayout.NORTH);

        // Panel input
        JPanel formPanel = new JPanel();
        GroupLayout layout = new GroupLayout(formPanel);
        formPanel.setLayout(layout);
        layout.setAutoCreateGaps(true);
        layout.setAutoCreateContainerGaps(true);

        JLabel lblId = new JLabel("ID Pasien:");
        JLabel lblWaktu = new JLabel("Waktu Datang:");

        tfIdPasien = new JTextField();
        tfWaktu = new JTextField();

        btnTambah = new JButton("Tambah ke Antrian");
        btnTambah.setFocusPainted(false);
        btnTambah.setBackground(new Color(70, 130, 180));
        btnTambah.setForeground(Color.WHITE);

        layout.setHorizontalGroup(
                layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                .addComponent(lblId)
                                .addComponent(lblWaktu))
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                .addComponent(tfIdPasien)
                                .addComponent(tfWaktu)
                                .addComponent(btnTambah, GroupLayout.Alignment.TRAILING))
        );

        layout.setVerticalGroup(
                layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                .addComponent(lblId)
                                .addComponent(tfIdPasien))
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                .addComponent(lblWaktu)
                                .addComponent(tfWaktu))
                        .addComponent(btnTambah)
        );

        panel.add(formPanel, BorderLayout.CENTER);

        // Area tampilan antrian
        taAntrian = new JTextArea();
        taAntrian.setEditable(false);
        taAntrian.setFont(new Font("Monospaced", Font.PLAIN, 14));
        JScrollPane scrollPane = new JScrollPane(taAntrian);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Daftar Antrian"));
        panel.add(scrollPane, BorderLayout.SOUTH);

        btnTambah.addActionListener(e -> tambahAntrian());

        loadAntrian();
        setVisible(true);
    }

    private void tambahAntrian() {
        String id = tfIdPasien.getText().trim();
        String waktu = tfWaktu.getText().trim();

        if (id.isEmpty() || waktu.isEmpty()) {
            JOptionPane.showMessageDialog(this, "ID Pasien dan Waktu tidak boleh kosong!");
            return;
        }

        AntrianPasien ap = new AntrianPasien(id, waktu);

        File file = new File("data/antrian.csv");
        file.getParentFile().mkdirs();

        try (BufferedWriter w = new BufferedWriter(new FileWriter(file, true))) {
            w.write(ap.toCSV());
            w.newLine();
            JOptionPane.showMessageDialog(this, "Ditambahkan ke antrian.");
            tfIdPasien.setText("");
            tfWaktu.setText("");
            loadAntrian();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Gagal menambahkan.");
        }
    }

    private void loadAntrian() {
        taAntrian.setText("");
        File file = new File("data/antrian.csv");
        if (!file.exists()) return;

        try (BufferedReader r = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = r.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length < 2) continue;
                String id = data[0];
                String waktu = data[1];
                String nama = getNamaPasienById(id);
                taAntrian.append("[" + waktu + "] " + id + " - " + nama + "\n");
            }
        } catch (IOException e) {
            taAntrian.setText("Gagal load antrian.");
        }
    }

    private String getNamaPasienById(String id) {
        File file = new File("data/pasien.csv");
        if (!file.exists()) return "(Data pasien tidak ditemukan)";
        try (BufferedReader r = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = r.readLine()) != null) {
                String[] data = line.split(",");
                if (data[0].equals(id)) return data[1];
            }
        } catch (IOException e) {}
        return "(Nama tidak ditemukan)";
    }
}
