package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import model.Pasien;

public class FormRegistrasi extends JFrame {
    private JTextField tfId, tfNama, tfTgl, tfAlamat, tfHp;
    private JComboBox<String> cbJenisPasien;
    private JLabel avatarLabel;
    private JButton btnSimpan, btnUpload;
    private Runnable onSuksesRegistrasi;
    private ImageIcon avatarIcon;

    public FormRegistrasi(Runnable onSuksesRegistrasi) {
        this.onSuksesRegistrasi = onSuksesRegistrasi;

        setTitle("Registrasi Pasien");
        setSize(700, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel content = new JPanel(new BorderLayout());
        content.setBackground(new Color(220, 235, 250)); // Latar biru muda
        content.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));

        // Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(220, 235, 250));
        JLabel title = new JLabel("Form Registrasi Pasien", JLabel.CENTER);
        title.setFont(new Font("SansSerif", Font.BOLD, 22));
        headerPanel.add(title, BorderLayout.CENTER);
        content.add(headerPanel, BorderLayout.NORTH);

        // Body
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(new Color(220, 235, 250));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        tfId = createTextField("Masukkan ID Pasien");
        tfNama = createTextField("Masukkan Nama Lengkap");
        tfTgl = createTextField("dd/mm/yyyy");
        tfAlamat = createTextField("Masukkan Alamat");
        tfHp = createTextField("Masukkan No HP");
        cbJenisPasien = new JComboBox<>(new String[]{"Umum", "BPJS"});

        // Avatar dan upload
        avatarLabel = new JLabel();
        avatarLabel.setPreferredSize(new Dimension(80, 80));
        avatarLabel.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        avatarLabel.setHorizontalAlignment(JLabel.CENTER);
        avatarLabel.setIcon(new ImageIcon("FormRegistrasiAssets/assets/user.png")); // Default avatar

        btnUpload = new JButton("Upload Foto");
        btnUpload.addActionListener(e -> chooseAvatar());

        // Form layout
        addRow(formPanel, gbc, 0, "ID Pasien:", tfId, "FormRegistrasiAssets/assets/id.png");
        addRow(formPanel, gbc, 1, "Nama Lengkap:", tfNama, "FormRegistrasiAssets/assets/user.png");
        addRow(formPanel, gbc, 2, "Tanggal Lahir:", tfTgl, "FormRegistrasiAssets/assets/calendar.png");
        addRow(formPanel, gbc, 3, "Alamat:", tfAlamat, "FormRegistrasiAssets/assets/location.png");
        addRow(formPanel, gbc, 4, "No. HP:", tfHp, "FormRegistrasiAssets/assets/phone.png");
        addRow(formPanel, gbc, 5, "Jenis Pasien:", cbJenisPasien, "FormRegistrasiAssets/assets/type.png");

        gbc.gridx = 0;
        gbc.gridy = 6;
        JLabel lblFoto = new JLabel("Foto:");
        panelWithIcon(lblFoto, "FormRegistrasiAssets/assets/user.png");
        formPanel.add(lblFoto, gbc);

        gbc.gridx = 1;
        JPanel avatarPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        avatarPanel.setBackground(new Color(220, 235, 250));
        avatarPanel.add(avatarLabel);
        avatarPanel.add(btnUpload);
        formPanel.add(avatarPanel, gbc);

        content.add(formPanel, BorderLayout.CENTER);

        // Footer
        JPanel footerPanel = new JPanel();
        footerPanel.setBackground(new Color(220, 235, 250));
        btnSimpan = new JButton("Simpan Data Pasien");
        btnSimpan.setBackground(new Color(60, 130, 200));
        btnSimpan.setForeground(Color.WHITE);
        btnSimpan.setPreferredSize(new Dimension(200, 40));
        btnSimpan.setFocusPainted(false);

        btnSimpan.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                btnSimpan.setBackground(new Color(40, 110, 180));
            }
            public void mouseExited(MouseEvent e) {
                btnSimpan.setBackground(new Color(60, 130, 200));
            }
        });

        btnSimpan.addActionListener(e -> simpanPasien());

        footerPanel.add(btnSimpan);
        content.add(footerPanel, BorderLayout.SOUTH);

        setContentPane(content);
        setVisible(true);
    }

    private JTextField createTextField(String placeholder) {
        JTextField tf = new JTextField();
        tf.setForeground(Color.GRAY);
        tf.setText(placeholder);
        tf.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                if (tf.getText().equals(placeholder)) {
                    tf.setText("");
                    tf.setForeground(Color.BLACK);
                }
            }
            public void focusLost(FocusEvent e) {
                if (tf.getText().isEmpty()) {
                    tf.setText(placeholder);
                    tf.setForeground(Color.GRAY);
                }
            }
        });
        return tf;
    }

    private void addRow(JPanel panel, GridBagConstraints gbc, int y, String label, JComponent input, String iconPath) {
        gbc.gridx = 0;
        gbc.gridy = y;
        JLabel lbl = new JLabel(label);
        panelWithIcon(lbl, iconPath);
        panel.add(lbl, gbc);

        gbc.gridx = 1;
        panel.add(input, gbc);
    }

    private void panelWithIcon(JLabel label, String iconPath) {
        try {
            ImageIcon icon = new ImageIcon(iconPath);
            Image img = icon.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
            label.setIcon(new ImageIcon(img));
        } catch (Exception e) {
            System.out.println("Icon not found: " + iconPath);
        }
    }

    private void chooseAvatar() {
        JFileChooser chooser = new JFileChooser();
        int result = chooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            avatarIcon = new ImageIcon(chooser.getSelectedFile().getAbsolutePath());
            Image scaled = avatarIcon.getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH);
            avatarLabel.setIcon(new ImageIcon(scaled));
        }
    }

    private void simpanPasien() {
        if (tfId.getText().trim().isEmpty() || tfNama.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Harap lengkapi semua data.", "Validasi", JOptionPane.WARNING_MESSAGE);
            return;
        }
        Pasien p = new Pasien(
                tfId.getText(), tfNama.getText(), tfTgl.getText(),
                tfAlamat.getText(), tfHp.getText()
        );
        try (BufferedWriter w = new BufferedWriter(new FileWriter("FormRegistrasiAssets/data/pasien.csv", true))) {
            w.write(p.toCSV());
            w.newLine();
            JOptionPane.showMessageDialog(this, "\u2713 Data pasien berhasil disimpan!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
            dispose();
            if (onSuksesRegistrasi != null) onSuksesRegistrasi.run();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Terjadi kesalahan saat menyimpan data.");
        }
    }

    // Main method agar bisa langsung run
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new FormRegistrasi(null));
    }
}
